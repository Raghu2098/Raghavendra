def find_missing_number(arr):
    n = len(arr) + 1  
    total_sum = (n * (n + 1)) // 2  
    array_sum = sum(arr) 
    
    missing_number = total_sum - array_sum
    return missing_number
numbers = [9, 7, 5, 6, 2, 3, 6, 4,]
missing_number = find_missing_number(numbers)
print("The missing number is:", missing_number)